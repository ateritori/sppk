Sistem Pendukung Pembuatan Keputusan (SPKK) Metode Simple Addictive Weighing (SAW)

Ini adalah modifikasi dan pengembangan dari open Public Apps SPK SAW yang telah dibuat sebelumnya.
Kredit Untuk Pembuat Project Sebelumnya.

Pengembangan yang dilakukan adalah:
1. Updating Status Alternatif
2. Membuat Kriteria dan Sub Kriteria
3. Membuat Rentang Nilai dan Atau Kombinasi Isian Penilaian Manual
4. Hasil Input Penilaian Rinci
5. Hasil Penilaian Ternormalisasi Rinci
6. Hasil Nilai x Bobot Rinci
7. Hasil Nilai Preferensi
8. Hasil Perhitungan SAW
9. Rincian Langkah-Langkah

<img width="1680" alt="Screenshot 2024-10-18 at 00 54 29" src="https://github.com/user-attachments/assets/9fcf0205-8ff2-42a6-8810-3c4867dc0e3a">
<img width="1680" alt="Screenshot 2024-10-18 at 00 54 45" src="https://github.com/user-attachments/assets/a58c0c15-9499-41c3-aa10-a3907c4db220">
<img width="1680" alt="Screenshot 2024-10-18 at 00 54 56" src="https://github.com/user-attachments/assets/818af22c-c61a-4a92-a36f-3a99c3a8424f">
<img width="1680" alt="Screenshot 2024-10-18 at 00 55 04" src="https://github.com/user-attachments/assets/ca9c4de3-dead-457a-bc4a-5098d0d8953a">
<img width="1680" alt="Screenshot 2024-10-18 at 00 55 11" src="https://github.com/user-attachments/assets/744e7f3a-28cf-4fb2-b28a-204c10b835cf">
<img width="1680" alt="Screenshot 2024-10-18 at 00 55 22" src="https://github.com/user-attachments/assets/7c86f7f4-b8fb-44e2-a467-016cfb918de5">
<img width="1680" alt="Screenshot 2024-10-18 at 00 55 29" src="https://github.com/user-attachments/assets/723d1420-92a9-4b48-a40e-b9ab4953b6d3">
<img width="1680" alt="Screenshot 2024-10-18 at 00 55 40" src="https://github.com/user-attachments/assets/70b4bf63-5151-4992-a2c1-25e326a3054e">
<img width="1680" alt="Screenshot 2024-10-18 at 00 55 49" src="https://github.com/user-attachments/assets/1632bcfe-534a-441c-aca7-47af11f4194e">
<img width="1680" alt="Screenshot 2024-10-18 at 00 56 01" src="https://github.com/user-attachments/assets/2313afe2-7376-46c8-a35e-c603623eb34d">
<img width="1680" alt="Screenshot 2024-10-18 at 00 56 21" src="https://github.com/user-attachments/assets/fd5faee6-ae0b-4f07-8b29-0937f60d2ebe">
<img width="1680" alt="Screenshot 2024-10-18 at 00 56 35" src="https://github.com/user-attachments/assets/af2e6549-6bcc-47ce-abdf-6195b55ed0dd">
<img width="1680" alt="Screenshot 2024-10-18 at 00 56 43" src="https://github.com/user-attachments/assets/f22761b0-220e-4542-a581-c47fa3143d97">
<img width="1680" alt="Screenshot 2024-10-18 at 00 56 45" src="https://github.com/user-attachments/assets/17c8fb13-9f8b-44a8-8ef4-295499b7f355">

Didiskusikan oleh:
Ubaidilah AT
Rohana Murniati F
Meilin Budiarti
